import json
import boto3

def lambda_handler(event, context):
    client = boto3.client('sns')
    response = client.publish(
        TopicArn='',   # Provide ARN of the SNS Topic created
        Message='Test Message, Just Avoid',
        Subject='Test'
)
